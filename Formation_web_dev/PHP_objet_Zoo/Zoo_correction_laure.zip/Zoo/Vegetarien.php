<?php

class Vegetarien extends Animal
{
    public function coutNourriture()
    {
        $qt = $this->nbKg + 5;
        $qt = ($qt*2)+1;
        $qt = $qt +1;
        return round(1.2*(log10($qt)),2);
    }

}