<?php
include ('Animal.php');

class Carnivore extends Animal
{
   public function coutNourriture()
   {
       return (pow(($this->nbKg *10), 2)+100);
   }
}