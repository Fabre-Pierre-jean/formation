<?php
include('Zoo.php');
include ('Tigre.php');
include('Vegetarien.php');

$zoo = new Zoo('Barben', 25);

$tigre = new Tigre(120, 4,'Fantôme', 'feulement','Tigre du Bengale', 14);
$autruche = new Vegetarien(50,5,'Ann', 'beuglement', 'Autruche');

$zoo->addAnimal($tigre);
$zoo->addAnimal($autruche);

echo "La nourriture par jour coûte: ".$zoo->coutBouffe()."euros. ";

echo $zoo->zooToString();