<?php

class Zoo
{
    private $nom;
    private $animaux;
    private $nbPlaces;

    public function __construct($nom, $nbPlaces)
    {
        $this->nom = $nom;
        $this->nbPlaces = $nbPlaces;
        $this->animaux = [];
    }

    public function addAnimal(Animal $animal)
    {
        $this->animaux[]=$animal;
    }

    public function supprAnimal(Animal $animal)
    {
        unset($this->animaux[array_search($animal, $this->animaux)]);
        array_values($this->animaux);
    }

    public function zooToString()
    {
        $string = "Il y a ". $this->nbAnimauxPresents(). "animaux dans le zoo ".$this->nom." :";
        foreach ($this->animaux as $animal)
        {
            $string .= $animal->_toString();
        }
       return $string;
    }

    /**
     * @return int
     */
    public function nbAnimauxPresents()
    {
        return count($this->animaux);
    }

    /**
     * @return int
     */
    public function coutBouffe()
    {
        $cout=0;
        foreach ($this->animaux as $animal)
        {
            $cout += $animal->coutNourriture();
            echo "le coût pour animal est :".$animal->coutNourriture();
        }
        return $cout;
    }
}