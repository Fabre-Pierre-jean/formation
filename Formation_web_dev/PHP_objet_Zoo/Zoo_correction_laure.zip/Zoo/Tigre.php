<?php
include('Carnivore.php');

class Tigre extends Carnivore
{
    public $nbRayures;
    public $cri = 'feulement';

    public function __construct(int $poids, int $nbKg, String $nom, $cri, $espece, int $nbRayures)
    {
        parent::__construct($poids, $nbKg, $nom, $this->cri, $espece);
        $this->nbRayures = $nbRayures;
    }

    /**
     * @return int
     */
    public function getNbRayures(): int
    {
        return $this->nbRayures;
    }

}