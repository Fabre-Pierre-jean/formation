<?php
include ('Carnivore.php');
include('Vegetarien.php');

$aigle = new Carnivore(1, 25,'GrandAigle', 'sifflement', 'aigle');
$chimpanze = new Vegetarien(3, 55,'Cheeta', 'hurlement', 'chimpanzé');

echo $aigle->_toString();
echo $chimpanze->_toString();

echo $aigle->coutNourriture();
echo $chimpanze->coutNourriture();