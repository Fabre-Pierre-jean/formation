<?php

abstract class Animal
{
    protected $poids;
    protected $nbKg;
    protected $nom;
    protected $cri;
    protected $espece;

    /**
     * Animal constructor.
     * @param int $poids
     * @param int $nbKg
     * @param String $nom
     * @param String $cri
     * @param String $espece
     */
    public function __construct(int $poids, int $nbKg, String $nom, String $cri, String $espece)
    {
        $this->poids = $poids;
        $this->nbKg = $nbKg;
        $this->nom = $nom;
        $this->cri =$cri;
        $this->espece = $espece;
    }

    /**
     * @return string
     */
    public function _toString()
    {
        return "L'animal pèse ".$this->nbKg." kg, il se nomme ".$this->nom." et appartient à l'espèce ".$this->espece.". Il pousse un ".$this->cri.".";
    }

    /**
     * @return mixed
     */
    abstract public function coutNourriture();

}